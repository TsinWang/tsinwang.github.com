package com.example.proximitygesture;

import android.app.admin.DeviceAdminReceiver;

public class SensorService$deviceAdminReceiver extends DeviceAdminReceiver{

}
